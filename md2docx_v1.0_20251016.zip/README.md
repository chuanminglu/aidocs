# Markdown 转 Word 工具 (绿色版)

## 📋 简介

这是一个独立的 Markdown 到 Word 文档转换工具，无需安装 Python 环境即可运行。

**版本**: 1.0  
**文件**: md2docx.exe  
**大小**: 约 19 MB  
**系统要求**: Windows 7/8/10/11 (64位)

## ✨ 特性

- ✅ **绿色便携** - 单个 exe 文件，无需安装
- ✅ **完整功能** - 支持所有 Markdown 语法
- ✅ **代码块优化** - 完美保留代码格式和换行
- ✅ **图表支持** - 支持 PlantUML、Mermaid 图表
- ✅ **表格美化** - 自动美化表格格式
- ✅ **中文友好** - 完美支持中文文件名和内容
- ✅ **一键转换** - 拖放文件或命令行运行

## 🚀 快速开始

### 方法 1: 拖放文件 (最简单)

1. 找到你的 `.md` 文件
2. 直接拖放到 `md2docx.exe` 图标上
3. 自动生成同名的 `.docx` 文件

![拖放演示](drag-drop.gif)

### 方法 2: 命令行运行

#### 基本用法

```cmd
# 自动生成输出文件名（与输入文件同名）
md2docx.exe input.md

# 输出文件会自动生成为 input.docx
```

#### 指定输出文件

```cmd
# 指定输出文件名
md2docx.exe input.md -o output.docx

# 指定输出路径
md2docx.exe input.md -o C:\Documents\output.docx
```

#### 处理中文文件名

```cmd
# 中文文件名需要用引号包围
md2docx.exe "项目文档.md"
md2docx.exe "产品需求.md" -o "PRD文档.docx"
```

#### 查看帮助

```cmd
md2docx.exe --help
md2docx.exe -h
```

### 方法 3: 右键菜单 (需配置)

可以将 `md2docx.exe` 添加到右键菜单，实现右键转换：

1. 按 `Win + R` 打开运行对话框
2. 输入 `regedit` 打开注册表编辑器
3. 导航到 `HKEY_CLASSES_ROOT\.md\shell`
4. 添加新项 "转换为Word"
5. 在该项下创建 `command` 子项
6. 设置值为: `"C:\path\to\md2docx.exe" "%1"`

## 📖 支持的 Markdown 语法

### 基本语法

- **标题**: `#` 到 `######`
- **粗体**: `**粗体**` 或 `__粗体__`
- **斜体**: `*斜体*` 或 `_斜体_`
- **删除线**: `~~删除~~`
- **代码**: `` `代码` ``
- **链接**: `[链接文本](URL)`
- **图片**: `![图片](URL)`
- **引用**: `> 引用内容`
- **列表**: `-` 或 `*` 或 `1.`

### 高级功能

#### 代码块

```python
def hello():
    print("Hello, World!")
```

#### 表格

| 列1 | 列2 | 列3 |
|-----|-----|-----|
| 数据1 | 数据2 | 数据3 |

#### PlantUML 图表

```plantuml
@startuml
Alice -> Bob: Hello
Bob -> Alice: Hi
@enduml
```

#### Mermaid 图表

```mermaid
graph TD
    A[开始] --> B[处理]
    B --> C[结束]
```

## 💡 使用技巧

### 1. 批量转换

创建批处理文件 `batch_convert.bat`:

```batch
@echo off
for %%f in (*.md) do (
    echo 转换: %%f
    md2docx.exe "%%f"
)
echo 批量转换完成！
pause
```

### 2. 添加到 PATH

将 `md2docx.exe` 所在目录添加到系统 PATH，这样可以在任意位置运行：

```cmd
# 在任意目录下直接使用
md2docx document.md
```

**添加步骤**:
1. 右键 "此电脑" → "属性"
2. 点击 "高级系统设置"
3. 点击 "环境变量"
4. 在 "系统变量" 中找到 "Path"，点击 "编辑"
5. 添加 `md2docx.exe` 所在的目录路径

### 3. 创建桌面快捷方式

1. 右键 `md2docx.exe` → "创建快捷方式"
2. 将快捷方式拖到桌面
3. 直接拖放文件到桌面快捷方式即可转换

### 4. 在 VSCode 中集成

在 VSCode 的 `tasks.json` 中添加任务（参见 `vscode-tasks-portable.json`）

## 🔧 常见问题

### Q: 转换后的 Word 文档在哪里？

**A**: 默认生成在输入文件的同一目录下，文件名相同但扩展名为 `.docx`

### Q: 为什么图表没有显示？

**A**: 
- PlantUML 图表需要网络连接（调用 PlantUML 服务器）
- 确保 Markdown 中图表语法正确
- 检查代码块标记是否正确（``` 三个反引号）

### Q: 中文显示乱码怎么办？

**A**: 
- 确保 Markdown 文件是 UTF-8 编码
- 用记事本打开，另存为时选择 "UTF-8" 编码

### Q: 文件太大，转换很慢？

**A**: 
- 大文件（>1MB）转换可能需要几秒到几十秒
- 包含大量图表的文档转换时间会更长
- 请耐心等待，不要关闭窗口

### Q: 能否转换网络上的 Markdown 文件？

**A**: 
- 目前只支持本地文件
- 可以先下载到本地再转换

### Q: 转换失败怎么办？

**A**: 
1. 检查输入文件是否是有效的 Markdown 文件
2. 检查文件路径是否包含特殊字符
3. 尝试使用绝对路径
4. 查看错误信息，根据提示修复

### Q: 杀毒软件报警？

**A**: 
- 这是 PyInstaller 打包的程序常见的误报
- 可以添加到杀毒软件白名单
- 或临时关闭杀毒软件再运行

## 📊 转换示例

### 示例 1: 技术文档

**输入**: `api_docs.md`
```markdown
# API 文档

## 用户登录

**接口**: POST /api/login

**参数**:
- username: 用户名
- password: 密码
```

**输出**: `api_docs.docx` - 格式化的 Word 文档

### 示例 2: 项目需求

**输入**: `requirements.md`
```markdown
# 项目需求文档

| 功能 | 优先级 | 状态 |
|------|--------|------|
| 用户登录 | P0 | 完成 |
| 数据导出 | P1 | 进行中 |
```

**输出**: `requirements.docx` - 包含美化表格的 Word 文档

## 🎨 Word 文档样式

生成的 Word 文档具有以下样式特点：

- **字体**: 微软雅黑 (中文) / Calibri (英文)
- **代码字体**: Consolas / Courier New
- **标题**: 自动分级，带编号
- **表格**: 自动美化，带边框和底色
- **代码块**: 灰色背景，等宽字体
- **图表**: 1:1 比例，居中显示
- **页面**: A4 纸张，标准页边距

## 📄 支持的文件格式

### 输入格式

- `.md` - Markdown 文件
- `.markdown` - Markdown 文件（另一种扩展名）

### 输出格式

- `.docx` - Word 2007+ 格式 (Office Open XML)

## 🔒 隐私和安全

- ✅ **完全离线** - 除图表渲染外，所有处理都在本地完成
- ✅ **无数据收集** - 不收集、不上传任何用户数据
- ✅ **无网络请求** - 除 PlantUML 图表渲染（可选）
- ✅ **开源透明** - 源代码可在 GitHub 查看

## 📞 技术支持

### 问题反馈

如遇到问题或有建议，请通过以下方式反馈：

- **GitHub Issues**: [项目地址](https://github.com/your-repo)
- **Email**: your-email@example.com

### 版本更新

查看最新版本和更新日志：
- 访问 GitHub 仓库的 Releases 页面
- 下载最新版本的 `md2docx.exe`

## 📜 许可证

本工具基于 MIT 许可证开源。

---

## 🚀 高级用法

### 在 PowerShell 中使用

```powershell
# 转换当前目录下所有 md 文件
Get-ChildItem -Filter *.md | ForEach-Object {
    & .\md2docx.exe $_.FullName
}

# 转换指定目录
Get-ChildItem -Path "C:\Documents" -Filter *.md -Recurse | ForEach-Object {
    & .\md2docx.exe $_.FullName -o "$($_.DirectoryName)\$($_.BaseName).docx"
}
```

### 在 Python 脚本中调用

```python
import subprocess
import os

def convert_md_to_docx(md_file):
    exe_path = r"C:\path\to\md2docx.exe"
    subprocess.run([exe_path, md_file], check=True)

# 使用
convert_md_to_docx("document.md")
```

### 在批处理脚本中使用

```batch
@echo off
setlocal enabledelayedexpansion

set "MD2DOCX=C:\path\to\md2docx.exe"

for %%f in (*.md) do (
    echo 正在转换: %%f
    "%MD2DOCX%" "%%f"
    if !errorlevel! equ 0 (
        echo ✓ 转换成功: %%~nf.docx
    ) else (
        echo ✗ 转换失败: %%f
    )
)

echo.
echo 全部转换完成！
pause
```

## 🎯 应用场景

1. **技术文档** - API 文档、技术规范
2. **项目管理** - 需求文档、项目计划
3. **知识管理** - 笔记、Wiki 转换
4. **内容创作** - 博客文章、教程文档
5. **学术写作** - 论文草稿、研究报告
6. **团队协作** - 将 Git 仓库的 README 转为 Word

## 💻 系统要求

- **操作系统**: Windows 7/8/10/11 (64位)
- **磁盘空间**: 至少 50 MB 可用空间
- **内存**: 建议 2GB 以上
- **网络**: 仅 PlantUML 图表需要网络（可选）

## 🆕 更新历史

### v1.0 (2025-01-16)
- ✨ 首个发布版本
- ✅ 支持完整的 Markdown 语法
- ✅ 优化代码块换行处理
- ✅ 支持 PlantUML 和 Mermaid 图表
- ✅ 美化表格格式
- ✅ 绿色便携版打包

---

**感谢使用 Markdown 转 Word 工具！** 🎉
