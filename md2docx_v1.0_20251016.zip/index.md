# 📦 md2docx - Markdown 转 Word 工具

## 📂 本目录文件

### 核心文件
- **md2docx.exe** - 主程序（绿色版，19MB）

### 使用文档  
- **快速开始.md** - 30秒快速上手 ⚡
- **README.md** - 完整使用说明 📖
- **分发说明.md** - 分发指南 📦

### VSCode 集成（可选）
- **vscode-tasks.json** - VSCode 任务配置
- **import_tasks.ps1** - 一键导入脚本

## ⚡ 快速开始

### 最简单的方法
1. 拖放 `.md` 文件到 `md2docx.exe`
2. 完成！

### 命令行方法
```cmd
md2docx.exe 你的文件.md
```

## 📖 详细说明

| 需求 | 查看文档 |
|------|----------|
| 快速上手 | `快速开始.md` |
| 完整功能 | `README.md` |
| 分发指南 | `分发说明.md` |
| VSCode集成 | 运行 `import_tasks.ps1` |

## 🎯 VSCode 集成

如果你使用 VSCode：

1. 在本目录运行：
   ```powershell
   .\import_tasks.ps1
   ```

2. 然后按 `Ctrl+Shift+B` 即可快速转换

## ✨ 主要特性

- ✅ 无需安装 Python
- ✅ 绿色便携，随处可用
- ✅ 支持完整 Markdown 语法
- ✅ 完美处理代码块换行
- ✅ 支持表格、图表
- ✅ 中文文件名友好

## 📞 需要帮助？

1. 查看 **快速开始.md** - 快速入门
2. 查看 **README.md** - 详细说明
3. 运行 `md2docx.exe --help` - 查看命令帮助

---

**开始使用吧！** 🚀

*版本: 1.0*
